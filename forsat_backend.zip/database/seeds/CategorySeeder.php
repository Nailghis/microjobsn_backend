<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //create seeding method
        DB::table('categories')->insert([
            [
                'name' => 'Scolarship'
            ],
            [
                'name' => 'Fellowship'
            ],
            [
                'name' => 'Internship'
            ]
        ]);
    }
}
